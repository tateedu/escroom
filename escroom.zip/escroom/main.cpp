#include "game.h"

int main()
{
  game Game{};
  Game.run();
  return 0;
}
