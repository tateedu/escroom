#include "game.h"

bool game::initialize()
{
  if (sv.check())
  {
    system("clear");
    std::cout << "Detected a save file\n";
    std::cout << "Would you like to load from your last save? [y/n]: ";
    int state = sv.getState();
    switch (inp.yn())
    {
      case 'y':
        loading::animate(3.0);
        if (state == 1)
          partOne();
        else if (state == 2)
          partTwo();
        else if (state == 3)
          partThree();
        else
          std::cout << "Unrecognized save state...\nAre you tampering with the save files?...\n";
        return false;
        break;
      case 'n':
        system("clear");
        break;
      case 'e':
        break;
      case 'f':
        failureExit();
        break;
    }
  }
  return true;
}

void game::introduction()
{
  std::cout << "Welcome to my game!\n";
  std::cout << "If at any point you need to exit, type 'EXIT'\n";
  std::cout << "Are you ready to play? [y/n]: ";
  switch (inp.yn())
  {
    case 'y':
      partOne();
      break;
    case 'n':
      system("clear");
      std::cout << "Wow... rude\n";
      break;
    case 'e':
      break;
    case 'f':
      failureExit();
      break;
  }
}

void game::partOne()
{
  //loading phase
  currentSaveID = 1;
  sv.sv(currentSaveID);
  loading::hacking(3.0);
  std::filesystem::path baseDir = "secretfolder";
  if (!std::filesystem::create_directory(baseDir))
  {
    std::cout << "Directory already exists or failed\n";
  }
  std::string openMeContents{
    "The following is a Caesar cipher...\nType how much it has shifted by when you see your answer...\nGood luck... (Only one Caesar cipher)\nOekh dunj fkppbu mybb duut q IXQ-256 xqixuh... qdt jxu xydj veh jxu cuiiqwu hxocui myjx zubbe, qdt yi kiut qi q whuujydw..."
  };
  std::string openMePath{ "secretfolder/openme.txt" };
  if (gameFile.create(openMePath))
  {
    gameFile.write(openMePath, openMeContents);
  }
  loading::animate(4.0);
  
  system("clear");

  //main game phase
  std::cout << "I now have all of your data...\n";
  system("sleep 2");
  std::cout << "I will expose you to all of the world unless you can complete these puzzles...\n";
  system("sleep 3");
  std::cout << "Are you ready?\n";
  system("sleep 2");
  std::cout << "Well I don't care so here we go!\n";
  system("sleep 1.5");
  system("clear");
  
  std::cout << "Check the folder you opened this game in...\n";
  system("sleep 3");
  std::cout << "A special folder will be seen...\n";
  system("sleep 2");
  std::cout << "Open it and you will see a text file...\n";
  system("sleep 2");
  std::cout << "Follow the instructions and come back to here...\n";
  system("sleep 15");
  
  std::string s_partOneUserAnswer{};
  int i_partOneUserAnswer{};
  int partOneCorrectAnswer{ 16 };
  while(true)
  {
    std::cout << "Answer [should be a number between 1-26]: ";
    std::getline(std::cin >> std::ws, s_partOneUserAnswer);
    if (s_partOneUserAnswer == "EXIT")
    {
      defaultExit();
      break;
    }
    
    try
    {
      i_partOneUserAnswer = std::stoi(s_partOneUserAnswer);
    }
    catch (const std::invalid_argument& e)
    {
      i_partOneUserAnswer = 0;
    }
    if (partOneCorrectAnswer == i_partOneUserAnswer)
    {
      partTwo();
      break;
    }
    else
    {
      system("clear");
      std::cout << "Incorrect!\n";
    }
  }
}

void game::partTwo()
{
  currentSaveID = 2;
  sv.sv(currentSaveID);
  system("clear");
  std::cout << "Good job!\n";
  system("sleep 3");
  system("clear");
  std::cout << "Now, your deciphered message has already given you your clue to the next puzzle...\n";
  system("sleep 4");
  std::string partTwoKey{ "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824" };
  std::string partTwoUserAnswer{};
  while(true)
  {
    std::cout << "Answer [should be really long]: ";
    std::getline(std::cin >> std::ws, partTwoUserAnswer);
    if (partTwoKey == partTwoUserAnswer)
    {
      partThree();
      break;
    }
    else if (partTwoUserAnswer == "EXIT")
    {
      defaultExit();
      break;
    }
    else
    {
      system("clear");
      std::cout << "Incorrect!\n";
    }
  }
}

void game::partThree()
{
  currentSaveID = 3;
  sv.sv(currentSaveID);
  system("clear");
  std::cout << "Congrats on Making it this far!\n";
  system("sleep 3");
  std::cout << "Now, go back to the folder you originally downloaded the game in...\n";
  system("sleep 3");
  std::cout << "There should be directory in there leading to an html file...\n";
  system("sleep 2");
  std::cout << "\nWARNING: the file is a .html file and sometimes when you open it, Apple and their stink will change the format to rich text.\nThis will make it not show up as html in your browser.\n(I recommend using the 'nano' command in your terminal to edit. Type 'nano path/to/file' )\n";
  system("sleep 3");
  std::cout << "\nHint: look for the hexadecimal tags (e.g. #111aa2)...\n";
  std::cout << "\nIlluminate your answer by changing a color...\n";
  system("sleep 4");
  
  std::string partThreeKey{ "yomama" };
  std::string partThreeUserAnswer{};
  while(true)
  {
    std::cout << "Answer: ";
    std::getline(std::cin >> std::ws, partThreeUserAnswer);
    if (partThreeKey == partThreeUserAnswer)
    {
      finishLine();
      break;
    }
    else if (partThreeUserAnswer == "EXIT")
    {
      defaultExit();
      break;
    }
    else
    {
      system("clear");
      std::cout << "Incorrect!\n";
    }
  }
}

void game::finishLine()
{
  currentSaveID = 0;
  sv.sv(currentSaveID);
  system("clear");
  std::cout << "Wow! Good job in getting through all the puzzles!\n";
  system("sleep 6");
  std::cout << "Your reward is a crisp, digital pat on the back\n";
  system("sleep 6");
  std::cout << "Thanks for playing!\n";
}

void game::defaultExit()
{
  system("clear");
  std::cout << "Would you like to save your progress? [y/n]: ";
  switch(inp.yn())
  {
    case 'y':
      sv.sv(currentSaveID);
      break;
    case 'n':
      break;
    case 'e':
      break;
    case 'f':
      failureExit();
      break;
  }
  std::cout << "Thanks for playing!\n";
}

void game::failureExit()
{
  system("clear");
  std::cerr << "\nAn error occured during the execution\n";
  std::cerr << "Try restarting...\n";
}

void game::run()
{
  system("clear");
  if (initialize())
  {
    system("clear");
    introduction();
  }
}
