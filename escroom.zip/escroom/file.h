#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

class file
{
public:
  std::string retrieve(std::string& fileName);
  bool write(std::string& fileName, std::string& contents);
  bool exists(std::string& fileName);
  bool create(std::string& fileName);
  bool trunc(std::string& fileName, std::string& contents);
  
private:
  std::ofstream m_fileHandler;
};
