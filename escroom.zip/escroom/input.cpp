#include "input.h"

char input::yn()
{
  std::string userInput{};
  bool inputting{ true };
  int inputCount{ 0 };
  
  while(inputting)
  {
    std::getline(std::cin >> std::ws, userInput);
    if (userInput == "EXIT")
    {
      return 'e';
    }
    if (userInput.size() > 1 || userInput.size() <= 0)
    {
      system("clear");
      std::cout << "Invalid input!\n";
      std::cout << "[y/n]: ";
      inputCount++;
      if (inputCount > 2)
        return 'f';
    }
    else if (userInput == "y" || userInput == "n")
    {
      return static_cast<char>(userInput[0]);
    }
    else
    {
      std::cerr << "ERROR::INPUT.CPP::INPUT::INDETERMINANT_ERROR\n";
      return 'f';
    }
  }
  
  return 'f';
}
