#pragma once

#include <filesystem>

#include "loading.h"
#include "input.h"
#include "save.h"

class game
{
public:
  bool initialize();
  bool isSaved();
  void confirmNoSave();
  void introduction();
  void partOne();
  void partTwo();
  void partThree();
  void finishLine();
  void defaultExit();
  void failureExit();
  void run();
  
private:
  input inp{};
  save sv{};
  file gameFile{};
  
  int currentSaveID{};
};
