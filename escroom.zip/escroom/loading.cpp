#include "loading.h"

void loading::animate(double delay)
{
  std::time_t startTime = std::time(0);
  double duration{ delay };
  
  bool isRunning{ true };
  while(isRunning)
  {
    std::time_t currentTime = std::time(nullptr);
    
    system("clear");
    
    if (currentTime == 1.0 + startTime || currentTime == 4.0 + startTime)
    {
      std::cout << "Loading.\n";
    }
    if (currentTime == 2.0 + startTime || currentTime == 5.0 + startTime)
    {
      std::cout << "Loading..\n";
    }
    if (currentTime == 3.0 + startTime || currentTime == 6.0 + startTime)
    {
      std::cout << "Loading...\n";
    }
    
    system("sleep 1");
    
    if (currentTime == startTime + duration)
    {
      isRunning = false;
    }
  }
}

void loading::hacking(double delay)
{
  std::time_t startTime = std::time(0);
  double duration{ delay };
  
  bool isRunning{ true };
  while(isRunning)
  {
    std::time_t currentTime = std::time(nullptr);
    
    system("clear");
    
    if (currentTime == 1.0 + startTime)
    {
      std::cout << "Hacking.\n";
    }
    if (currentTime == 2.0 + startTime)
    {
      std::cout << "Hacking..\n";
    }
    if (currentTime == 3.0 + startTime)
    {
      std::cout << "Hacking...\n";
    }
    
    system("sleep 1");
    
    if (currentTime == startTime + duration)
    {
      system("clear");
      std::cout << "System Compromised\n";
      system("sleep 1");
      system("clear");
      isRunning = false;
    }
  }
}
