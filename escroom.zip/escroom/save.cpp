#include "save.h"

bool save::checkNum(char given) const
{
  if (given >= '0' && given <= '9')
  {
    return true;
  }
  else
  {
    return false;
  }
}

bool save::check()
{
  std::string fileFetch = svFileHandler.retrieve(saveFile);
  if (fileFetch == "f")
  {
    std::cout << "Failure in opening save file...\n";
    system("sleep 1");
    std::cout << "Creating new save file...\n";
    system("sleep 1");
    svFileHandler.create(saveFile);
    svFileHandler.write(saveFile, defaultState);
    return false;
  }
  else if (checkNum(fileFetch[0]))
  {
    //subtracting '0' because any char converted to an int and subtracted by the char '0' will convert to their int counterpart
    savedState = static_cast<int>(fileFetch[0]) - '0';
    if (savedState == 0)
    {
      return false;
    }
    if(savedState > 0 && savedState <= 3)
    {
      return true;
    }
    return false;
  }
  else
  {
    std::cerr << "ERROR::SAVE.CPP::CHECK::POSSIBLE_TAMPERING_WITH_SAVE_FILE\n";
  }
  return false;
}

void save::load()
{
  
}

bool save::sv(const int gameState)
{
  std::string temp = std::to_string(gameState);
  svFileHandler.trunc(saveFile, temp);
  return false;
}

bool save::create()
{
  return false;
}

int save::getState()
{
  return savedState;
}
