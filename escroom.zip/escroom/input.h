#pragma once

#include <iostream>
#include <string>

class input
{
public:
  char yn();
  
private:
};
