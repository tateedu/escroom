#pragma once

#include "file.h"

class save
{
public:
  bool checkNum(char given) const;
  bool check();
  void load();
  bool sv(const int gameState);
  bool create();
  int getState();
  
private:
  std::string defaultState{ "0" };
  std::string saveFile{ "JuGtqP.txt" };
  
  int savedState{ 0 };
  
  file svFileHandler{};
};
