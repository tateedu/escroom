#pragma once

#include <iostream>
#include <cstdlib>
#include <ctime>

class loading
{
public:
  static void animate(double delay);
  static void hacking(double delay);
  
private:
  
};
