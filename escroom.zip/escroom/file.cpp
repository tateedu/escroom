#include "file.h"

std::string file::retrieve(std::string& fileName)
{
  std::string contents{ "f" };
  if (exists(fileName))
  {
    std::ifstream tempFile(fileName, std::ios::app | std::ios::binary);
    if (tempFile.is_open())
    {
      tempFile.seekg(0, std::ios::end);
      contents.resize(tempFile.tellg());
      tempFile.seekg(0, std::ios::beg);
      tempFile.read(&contents[0], contents.size());
      tempFile.close();
      return contents;
    }
    else
    {
      std::cerr << "ERROR::FILE.CPP::WRITE::FAILURE_OPENING_FILE\n";
      return contents;
    }
  }
  else
  {
    std::cerr << "ERROR::FILE.CPP::WRITE::FILE_DOES_NOT_EXIST\n";
    return contents;
  }
}

bool file::write(std::string& fileName, std::string& contents)
{
  if (exists(fileName))
  {
    m_fileHandler.open(fileName, std::ios::app);
    if (m_fileHandler.is_open())
    {
      m_fileHandler << contents << '\n';
      m_fileHandler.close();
      return true;
    }
    else
    {
      std::cerr << "ERROR::FILE.CPP::WRITE::FAILURE_OPENING_FILE\n";
      return false;
    }
  }
  else
  {
    std::cerr << "ERROR::FILE.CPP::WRITE::FILE_DOES_NOT_EXIST\n";
    return false;
  }
}

bool file::exists(std::string& fileName)
{
  std::ifstream file(fileName, std::ios::in);
  if (file.good())
  {
    file.close();
    return true;
  }
  else
  {
    file.close();
    return false;
  }
}

bool file::create(std::string& fileName)
{
  if (exists(fileName))
  {
    std::cerr << "ERROR::FILE.CPP::CREATE::FILE_ALREADY_EXISTS\n";
  }
  else
  {
    std::ofstream tempFile(fileName);
    if (tempFile.is_open())
    {
      return true;
    }
    else
    {
      std::cerr << "ERROR::FILE.CPP::CREATE::FAILED_TO_CREATE_FILE\n";
      return false;
    }
  }
  return false;
}

bool file::trunc(std::string& fileName, std::string& contents)
{
  if (exists(fileName))
  {
    m_fileHandler.open(fileName, std::ios::trunc);
    if (m_fileHandler.is_open())
    {
      m_fileHandler << contents << '\n';
      m_fileHandler.close();
      return true;
    }
    else
    {
      std::cerr << "ERROR::FILE.CPP::WRITE::FAILURE_OPENING_FILE\n";
      return false;
    }
  }
  else
  {
    std::cerr << "ERROR::FILE.CPP::WRITE::FILE_DOES_NOT_EXIST\n";
    return false;
  }
}
